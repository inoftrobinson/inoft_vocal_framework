# Project STORM > React diagrams > Demo Project

![](./screenshot.png)

In this repo you will find a simple webpack-dev-server project
that shows how to get started with the library.

It contains an example of how to implement a custom node in both Vanilla ES6 as well
as typescript (the recommended way).

Simply run `yarn start` and the server will start on port `9000`.

