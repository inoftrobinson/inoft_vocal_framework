import * as React from 'react';
export class BodyWidget extends React.Component {
    render() {
        return className;
        "diagram-container";
        engine = { this: .props.engine } /  > ;
    }
}
